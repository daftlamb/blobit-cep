#!/bin/bash
set -euo pipefail

EXT_ID="com.daftlamb.blobit"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions/$EXT_ID"

mkdir -p "$(dirname "$TARGET_DIR")"
rm -rf "$TARGET_DIR"
cp -R "$SCRIPT_DIR" "$TARGET_DIR"

find "$TARGET_DIR" -name ".DS_Store" -delete || true
chmod -R u+rwX "$TARGET_DIR"

echo ""
echo "Installed: $EXT_ID"
echo "Path: $TARGET_DIR"
echo "Restart Illustrator to load the panel."

