@echo off
setlocal

set EXT_ID=com.daftlamb.blobit
set SCRIPT_DIR=%~dp0
set TARGET_DIR=%APPDATA%\Adobe\CEP\extensions\%EXT_ID%

if not exist "%APPDATA%\Adobe\CEP\extensions" (
  mkdir "%APPDATA%\Adobe\CEP\extensions"
)

if exist "%TARGET_DIR%" (
  rmdir /s /q "%TARGET_DIR%"
)

xcopy "%SCRIPT_DIR%" "%TARGET_DIR%\" /E /I /H /Y >nul

echo.
echo Installed: %EXT_ID%
echo Path: %TARGET_DIR%
echo Restart Illustrator to load the panel.
pause

